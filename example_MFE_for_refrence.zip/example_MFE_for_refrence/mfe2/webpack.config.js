const { withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: "mfe2",
  exposes: {
    "./Module": "./src/app/mfe2/mfe2.module.ts", // ✅ Ensure this path is correct
  },
  shared: {
    "@angular/core": { singleton: true, strictVersion: true, requiredVersion: '19.2.2' },
    "@angular/common": { singleton: true, strictVersion: true, requiredVersion: '19.2.2' },
    "@angular/router": { singleton: true, strictVersion: true, requiredVersion: '19.2.2' }
  }
});
