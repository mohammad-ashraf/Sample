import { Routes } from '@angular/router';

export const routes: Routes = [
    {
      path: 'mfe2',
      loadChildren: () => import('./mfe2/mfe2.module').then(m => m.Mfe2Module)
    }
  ];
  
