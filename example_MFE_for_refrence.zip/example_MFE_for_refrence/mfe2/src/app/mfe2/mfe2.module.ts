import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { Mfe2Component } from './mfe2.component';

const routes: Routes = [
  { path: '', component: Mfe2Component }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [Mfe2Component]
})
export class Mfe2Module {}
