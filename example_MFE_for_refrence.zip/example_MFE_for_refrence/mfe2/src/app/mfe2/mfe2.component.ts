import { Component } from '@angular/core';

@Component({
  selector: 'app-mfe2',
  standalone: false, 
  templateUrl: './mfe2.component.html',
  styleUrl: './mfe2.component.css'
})
export class Mfe2Component {

}
