import { Component } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'shell';
 

  constructor(private router: Router) {}


  goToMFE1() {
    this.router.navigate(['/mfe1']);
  }

  goToMFE2() {
    this.router.navigate(['/mfe2']);
  }
}
