declare module 'mfe2/Module';
