const { withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  remotes: {
    mfe1: "mfe2@http://localhost:4201/remoteEntry.js",
    mfe2: "mfe2@http://localhost:4202/remoteEntry.js" // ✅ Ensure the correct format
  }
  ,
  shared: {
    "@angular/core": { singleton: true, strictVersion: true, requiredVersion: '19.2.2' },
    "@angular/common": { singleton: true, strictVersion: true, requiredVersion: '19.2.2' },
    "@angular/router": { singleton: true, strictVersion: true, requiredVersion: '19.2.2' }
  }
});
