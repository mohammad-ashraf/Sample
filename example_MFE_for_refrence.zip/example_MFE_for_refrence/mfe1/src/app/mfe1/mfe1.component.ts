import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  standalone: true, // ✅ Standalone component
  selector: 'app-mfe1',
  imports: [CommonModule], // ✅ Import necessary modules
  
  templateUrl: './mfe1.component.html',
  styleUrl: './mfe1.component.css'
})
export class Mfe1Component {

  constructor(private router: Router) {}



}
