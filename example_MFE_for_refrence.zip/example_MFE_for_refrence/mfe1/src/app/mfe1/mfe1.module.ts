import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Mfe1Component } from './mfe1.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild([
      { path: '', component: Mfe1Component } // ✅ Directly use standalone component
    ])
  ]
})
export class Mfe1Module {}
